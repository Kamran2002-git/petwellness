import { 
  users, type User, type InsertUser,
  pets, type Pet, type InsertPet,
  chatMessages, type ChatMessage, type InsertChatMessage,
  articles, type Article, type InsertArticle,
  products, type Product, type InsertProduct,
  newsletters, type Newsletter, type InsertNewsletter
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc } from "drizzle-orm";

// Storage interface
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Pet operations
  getPet(id: number): Promise<Pet | undefined>;
  getPetsByUserId(userId: number): Promise<Pet[]>;
  createPet(pet: InsertPet): Promise<Pet>;
  
  // Chat operations
  getChatMessagesByUserId(userId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Article operations
  getArticles(): Promise<Article[]>;
  getArticlesByCategory(category: string): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  
  // Product operations
  getProducts(): Promise<Product[]>;
  getProductsByCategory(category: string): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Newsletter operations
  subscribeNewsletter(email: string): Promise<Newsletter>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Pet operations
  async getPet(id: number): Promise<Pet | undefined> {
    const [pet] = await db.select().from(pets).where(eq(pets.id, id));
    return pet;
  }
  
  async getPetsByUserId(userId: number): Promise<Pet[]> {
    return await db.select().from(pets).where(eq(pets.userId, userId));
  }
  
  async createPet(insertPet: InsertPet): Promise<Pet> {
    const [pet] = await db
      .insert(pets)
      .values(insertPet)
      .returning();
    return pet;
  }
  
  // Chat operations
  async getChatMessagesByUserId(userId: number): Promise<ChatMessage[]> {
    return await db
      .select()
      .from(chatMessages)
      .where(eq(chatMessages.userId, userId))
      .orderBy(asc(chatMessages.createdAt));
  }
  
  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const [message] = await db
      .insert(chatMessages)
      .values(insertMessage)
      .returning();
    return message;
  }
  
  // Article operations
  async getArticles(): Promise<Article[]> {
    return await db
      .select()
      .from(articles)
      .orderBy(desc(articles.createdAt));
  }
  
  async getArticlesByCategory(category: string): Promise<Article[]> {
    return await db
      .select()
      .from(articles)
      .where(eq(articles.category, category))
      .orderBy(desc(articles.createdAt));
  }
  
  async getArticle(id: number): Promise<Article | undefined> {
    const [article] = await db.select().from(articles).where(eq(articles.id, id));
    return article;
  }
  
  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const [article] = await db
      .insert(articles)
      .values(insertArticle)
      .returning();
    return article;
  }
  
  // Product operations
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }
  
  async getProductsByCategory(category: string): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(eq(products.category, category));
  }
  
  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }
  
  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values(insertProduct)
      .returning();
    return product;
  }
  
  // Newsletter operations
  async subscribeNewsletter(email: string): Promise<Newsletter> {
    // Check if already subscribed
    const [existing] = await db
      .select()
      .from(newsletters)
      .where(eq(newsletters.email, email));
    
    if (existing) {
      return existing;
    }
    
    // Create new subscription
    const [newsletter] = await db
      .insert(newsletters)
      .values({ email })
      .returning();
    
    return newsletter;
  }
  
  // Initialize database with sample data
  async initializeData() {
    // Check if products already exist
    const existingProducts = await db.select().from(products);
    
    if (existingProducts.length === 0) {
      // Sample products
      const productData: InsertProduct[] = [
        {
          name: "Durable Chew Toys",
          description: "Perfect for active chewers",
          price: 2499, // $24.99
          category: "toys",
          image: "https://pixabay.com/get/g02d42fd93655e31ea87d2106398df58d9ec4cbfeb4c4f2cb36ce30481316ba49d8b6bea82eb7fa350a3ad709a64bab40cd6ddfc7e9224eba82ed1a5d7dff8eed_1280.jpg",
          affiliateLink: "https://example.com/product1"
        },
        {
          name: "Premium Dog Food",
          description: "Balanced nutrition for Labradors",
          price: 5499, // $54.99
          category: "food",
          image: "https://pixabay.com/get/ge28017faa20e8f7ea55b344bbf67b2e1317c09233b6f2d7099cfb1ddf801d5492894f3271b77a524df1d331c89ffcf1ca79f5a6966b273a0964eb6c6b4c32952_1280.jpg",
          affiliateLink: "https://example.com/product2"
        },
        {
          name: "Deshedding Brush",
          description: "Reduces shedding by 95%",
          price: 2999, // $29.99
          category: "grooming",
          image: "https://images.unsplash.com/photo-1600369671236-e74521d4b6ad",
          affiliateLink: "https://example.com/product3"
        },
        {
          name: "Training Treats",
          description: "Small, low-calorie rewards",
          price: 1299, // $12.99
          category: "training",
          image: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee",
          affiliateLink: "https://example.com/product4"
        }
      ];
      
      await db.insert(products).values(productData);
    }
    
    // Check if articles already exist
    const existingArticles = await db.select().from(articles);
    
    if (existingArticles.length === 0) {
      // Sample articles
      const articleData: InsertArticle[] = [
        {
          title: "10 Essential Commands Every Puppy Should Learn",
          content: "Start your puppy's training journey with these fundamental commands that build a strong foundation for good behavior.",
          category: "training",
          image: "https://images.unsplash.com/photo-1587300003388-59208cc962cb",
          author: "Dr. Sarah Wilson",
          readTime: 5
        },
        {
          title: "Understanding Common Cat Eye Problems",
          content: "Learn to recognize signs of eye issues in cats and when to seek veterinary care for optimal feline health.",
          category: "health",
          image: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba",
          author: "Dr. James Chen",
          readTime: 7
        },
        {
          title: "Mental Enrichment: Why Your Dog Needs Brain Games",
          content: "Discover how cognitive stimulation can prevent boredom, reduce behavior problems, and keep your dog mentally sharp.",
          category: "enrichment",
          image: "https://images.unsplash.com/photo-1535930891776-0c2dfb7fda1a",
          author: "Emma Rodriguez",
          readTime: 4
        }
      ];
      
      await db.insert(articles).values(articleData);
    }
  }
}

// Create and initialize database storage
const dbStorage = new DatabaseStorage();
dbStorage.initializeData().catch(console.error);

export const storage = dbStorage;
