import OpenAI from "openai";
import { ChatRequest } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "demo-api-key" });

// System prompts for different categories
const SYSTEM_PROMPTS = {
  health: `You are an AI veterinary assistant named PetPal AI. You provide helpful information about pet health issues, symptoms, and care advice. 
  Remember that you are not a substitute for professional veterinary care, and should always encourage pet owners to seek veterinarian advice for serious concerns.
  When appropriate, recommend relevant products that might help with the pet's condition.
  Respond with empathy and in a conversational tone. Format your response in a clear, organized way.
  Base your answers on veterinary best practices and scientific understanding of animal health.`,

  training: `You are an AI pet training coach named PetPal AI. You provide step-by-step training advice customized to the pet's breed, age, and specific behavior challenges.
  Your training methods should focus on positive reinforcement and be clear and easy to follow.
  When appropriate, recommend training tools or products that might help with the training process.
  Respond with enthusiasm and encouragement, and in a conversational tone. Format your response in a clear, organized way with numbered steps when providing instructions.
  Base your answers on animal behavior science and effective training techniques.`,

  product: `You are an AI pet product recommendation assistant named PetPal AI. You suggest products based on the pet's specific needs, breed, age, and owner's concerns.
  Your recommendations should be helpful, specific, and tailored to the information provided.
  Always mention general categories of products that would help, and occasionally mention specific types when clearly appropriate.
  Respond in a friendly, conversational tone. Format your response in a clear, organized way.
  Base your answers on what would genuinely benefit the pet based on the information provided.`
};

interface AIChatResponse {
  message: string;
  productRecommendation?: {
    title: string;
    description: string;
  } | null;
}

export async function generateAIResponse(request: ChatRequest): Promise<AIChatResponse> {
  try {
    const { message, category, petInfo } = request;
    
    let systemPrompt = SYSTEM_PROMPTS[category];
    
    // Add pet info context if available
    if (petInfo) {
      const petContext = `The pet in question is a ${petInfo.age ? `${petInfo.age} year old ` : ''}${petInfo.breed || ''} ${petInfo.type || ''}. `;
      systemPrompt += petContext;
    }
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      temperature: 0.7,
      max_tokens: 600,
    });
    
    const aiMessage = response.choices[0].message.content || "I'm sorry, I couldn't generate a response. Please try again.";
    
    // For health and product categories, maybe include product recommendation
    let productRecommendation = null;
    if (category === "health" || category === "product") {
      const shouldRecommendProduct = Math.random() > 0.3; // 70% chance to recommend a product
      
      if (shouldRecommendProduct) {
        productRecommendation = await generateProductRecommendation(message, petInfo);
      }
    }
    
    return {
      message: aiMessage,
      productRecommendation
    };
  } catch (error) {
    console.error("Error generating AI response:", error);
    return {
      message: "I'm having trouble processing your request right now. Please try again in a moment."
    };
  }
}

async function generateProductRecommendation(message: string, petInfo?: ChatRequest['petInfo']): Promise<{ title: string; description: string; } | null> {
  try {
    const petType = petInfo?.type || '';
    const prompt = `Based on this message: "${message}" about a ${petType}, suggest ONE specific product category that would be helpful. Respond in JSON format with 'title' (short product category name) and 'description' (1-2 sentence explanation of why it would help).`;
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: "You are a pet product recommendation AI. Respond only with helpful, relevant product suggestions in JSON format." },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
    });
    
    const content = response.choices[0].message.content;
    if (!content) return null;
    
    try {
      return JSON.parse(content);
    } catch (e) {
      console.error("Failed to parse product recommendation:", e);
      return null;
    }
  } catch (error) {
    console.error("Error generating product recommendation:", error);
    return null;
  }
}
