import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  pets: many(pets),
  chatMessages: many(chatMessages)
}));

export const pets = pgTable("pets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  type: text("type").notNull(), // dog, cat, bird, etc.
  breed: text("breed"),
  age: integer("age"),
  weight: integer("weight"),
  healthNotes: text("health_notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const petsRelations = relations(pets, ({ one }) => ({
  owner: one(users, {
    fields: [pets.userId],
    references: [users.id]
  })
}));

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  role: text("role").notNull(), // user or assistant
  content: text("content").notNull(),
  category: text("category").notNull(), // health, training, etc.
  createdAt: timestamp("created_at").defaultNow(),
});

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  user: one(users, {
    fields: [chatMessages.userId],
    references: [users.id]
  })
}));

export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(), // health, training, etc.
  image: text("image"),
  author: text("author"),
  readTime: integer("read_time"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  category: text("category").notNull(), // food, toys, health, etc.
  image: text("image"),
  affiliateLink: text("affiliate_link"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const newsletters = pgTable("newsletters", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertPetSchema = createInsertSchema(pets).omit({ id: true, createdAt: true });
export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({ id: true, createdAt: true });
export const insertArticleSchema = createInsertSchema(articles).omit({ id: true, createdAt: true });
export const insertProductSchema = createInsertSchema(products).omit({ id: true, createdAt: true });
export const insertNewsletterSchema = createInsertSchema(newsletters).omit({ id: true, createdAt: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertPet = z.infer<typeof insertPetSchema>;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type InsertArticle = z.infer<typeof insertArticleSchema>;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type InsertNewsletter = z.infer<typeof insertNewsletterSchema>;

export type User = typeof users.$inferSelect;
export type Pet = typeof pets.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type Article = typeof articles.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Newsletter = typeof newsletters.$inferSelect;

// Chat request schema
export const chatRequestSchema = z.object({
  message: z.string().min(1),
  category: z.enum(['health', 'training', 'product']),
  petInfo: z.object({
    type: z.string().optional(),
    breed: z.string().optional(),
    age: z.number().optional(),
  }).optional(),
});

export type ChatRequest = z.infer<typeof chatRequestSchema>;
