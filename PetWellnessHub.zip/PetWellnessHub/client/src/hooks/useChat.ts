import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Message {
  role: "user" | "assistant";
  content: string;
  productRecommendation?: {
    title: string;
    description: string;
  } | null;
}

export function useChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  
  const sendMessage = async (content: string, category: "health" | "training" | "product") => {
    // Add user message to chat
    const userMessage: Message = { role: "user", content };
    setMessages(prev => [...prev, userMessage]);
    
    setIsLoading(true);
    
    try {
      // Prepare pet info if needed
      const petInfo = {
        type: "dog", // Default values, in a real app these would come from user's profile
        breed: "Labrador Retriever",
        age: 3
      };
      
      // Send request to API
      const response = await apiRequest("POST", "/api/chat", {
        message: content,
        category,
        petInfo
      });
      
      const data = await response.json();
      
      // Add AI response to chat
      const assistantMessage: Message = { 
        role: "assistant", 
        content: data.message,
        productRecommendation: data.productRecommendation
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Chat error:", error);
      toast({
        title: "Error",
        description: "Failed to get a response. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return {
    messages,
    isLoading,
    sendMessage
  };
}
