export const dogBreeds = [
  "Labrador Retriever",
  "German Shepherd",
  "Golden Retriever",
  "French Bulldog",
  "Bulldog",
  "Poodle",
  "Beagle",
  "Rottweiler",
  "Dachshund",
  "Boxer"
];

export const catBreeds = [
  "Siamese",
  "Persian",
  "Maine Coon",
  "Ragdoll",
  "Bengal",
  "Abyssinian",
  "British Shorthair",
  "Sphynx",
  "Scottish Fold",
  "Birman"
];

export const petTypes = [
  { value: "dog", label: "Dog" },
  { value: "cat", label: "Cat" },
  { value: "bird", label: "Bird" },
  { value: "small_animal", label: "Small Animal" },
  { value: "fish", label: "Fish" },
  { value: "reptile", label: "Reptile" }
];

export const ageGroups = [
  { value: "puppy", label: "Puppy/Kitten (0-1 year)" },
  { value: "young_adult", label: "Young Adult (1-3 years)" },
  { value: "adult", label: "Adult (3-7 years)" },
  { value: "senior", label: "Senior (7+ years)" }
];

export const productCategories = [
  { value: "food", label: "Food & Treats" },
  { value: "toys", label: "Toys & Enrichment" },
  { value: "health", label: "Health & Wellness" },
  { value: "training", label: "Training Equipment" },
  { value: "grooming", label: "Grooming Supplies" },
  { value: "bedding", label: "Beds & Furniture" },
  { value: "travel", label: "Travel & Outdoors" }
];

export const commonHealthIssues = {
  dog: [
    "Ear Infections",
    "Skin Allergies",
    "Obesity",
    "Dental Disease",
    "Arthritis",
    "Vomiting/Diarrhea",
    "Eye Infections",
    "Urinary Tract Infections"
  ],
  cat: [
    "Dental Disease",
    "Vomiting/Hairballs",
    "Flea Infestations",
    "Obesity",
    "Urinary Tract Issues",
    "Kidney Disease",
    "Diabetes",
    "Respiratory Infections"
  ]
};

export const trainingChallenges = {
  dog: [
    "Potty Training",
    "Leash Pulling",
    "Excessive Barking",
    "Jumping on People",
    "Chewing Furniture",
    "Separation Anxiety",
    "Aggression",
    "Recall Training"
  ],
  cat: [
    "Litter Box Issues",
    "Scratching Furniture",
    "Jumping on Counters",
    "Aggression",
    "Excessive Meowing",
    "Play Biting",
    "Midnight Activity"
  ]
};
