import { Link } from "wouter";
import { useEffect, useRef, useState } from "react";

const Features = () => {
  const featureRefs = [useRef(null), useRef(null), useRef(null)];
  const [animatedFeatures, setAnimatedFeatures] = useState([false, false, false]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = featureRefs.findIndex(ref => ref.current === entry.target);
            if (index !== -1) {
              setAnimatedFeatures(prev => {
                const updated = [...prev];
                updated[index] = true;
                return updated;
              });
            }
          }
        });
      },
      { threshold: 0.2 }
    );

    featureRefs.forEach(ref => {
      if (ref.current) {
        observer.observe(ref.current);
      }
    });

    return () => {
      featureRefs.forEach(ref => {
        if (ref.current) {
          observer.unobserve(ref.current);
        }
      });
    };
  }, []);

  const featureCards = [
    {
      icon: "fa-stethoscope",
      color: "primary",
      title: "Virtual Vet Assistant",
      description: "Get instant answers to common pet health questions, symptom assessments, and recommendations for care.",
      linkText: "Try it now",
      linkHref: "/chat"
    },
    {
      icon: "fa-graduation-cap",
      color: "secondary",
      title: "Training Coach",
      description: "Custom step-by-step training guides tailored to your pet's breed, age, and behavior challenges.",
      linkText: "Start training",
      linkHref: "/training"
    },
    {
      icon: "fa-shopping-cart",
      color: "accent",
      title: "Smart Recommendations",
      description: "Personalized product suggestions based on your pet's specific needs, preferences, and health status.",
      linkText: "Explore products",
      linkHref: "/health"
    }
  ];

  return (
    <section id="features" className="py-16 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 fade-in">
          <h2 className="text-3xl font-bold mb-4 dark:text-white">AI-Powered Features</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Our intelligent assistant helps you take the best care of your pets with personalized advice, training plans, and product recommendations.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {featureCards.map((card, index) => (
            <div 
              key={index}
              ref={featureRefs[index]}
              className={`bg-neutral-light dark:bg-gray-800 rounded-xl p-6 shadow-sm hover-lift ${
                animatedFeatures[index] 
                  ? 'fade-in' 
                  : 'opacity-0 translate-y-10'
              }`}
              style={{ 
                transition: 'all 0.6s ease', 
                transitionDelay: `${index * 200}ms` 
              }}
            >
              <div className={`bg-${card.color}/10 dark:bg-${card.color}/20 w-12 h-12 rounded-full flex items-center justify-center mb-4 animate-pulse`}>
                <i className={`fas ${card.icon} text-${card.color} text-xl`}></i>
              </div>
              <h3 className="text-xl font-semibold mb-3 dark:text-white">{card.title}</h3>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                {card.description}
              </p>
              <Link href={card.linkHref}>
                <div className={`text-${card.color} font-medium flex items-center cursor-pointer hover:underline group`}>
                  {card.linkText} 
                  <i className={`fas fa-arrow-right ml-2 transition-transform duration-300 group-hover:translate-x-2`}></i>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
