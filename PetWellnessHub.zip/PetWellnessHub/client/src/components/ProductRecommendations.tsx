import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useQuery } from "@tanstack/react-query";

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  affiliateLink: string;
}

const ProductRecommendations = () => {
  const [petType, setPetType] = useState("Dog");
  const [breed, setBreed] = useState("Labrador Retriever");
  const [age, setAge] = useState("Adult (3-7 years)");
  const [category, setCategory] = useState("Food & Treats");
  
  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });
  
  return (
    <section className="py-16 bg-white dark:bg-gray-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-accent font-semibold">SMART RECOMMENDATIONS</span>
          <h2 className="text-3xl font-bold mt-2 mb-4 dark:text-white">AI-Powered Product Suggestions</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Get personalized product recommendations based on your pet's breed, age, health needs, and preferences.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="bg-neutral-light dark:bg-gray-800 rounded-xl p-6 shadow-sm">
              <div className="flex items-center mb-6">
                <div className="bg-accent/10 dark:bg-accent/20 rounded-full p-2 mr-3">
                  <i className="fas fa-shopping-basket text-accent"></i>
                </div>
                <h3 className="font-semibold dark:text-white">Smart Product Finder</h3>
              </div>
              
              <div className="space-y-4 mb-6">
                <div>
                  <Label htmlFor="pet-type">Pet Type</Label>
                  <Select value={petType} onValueChange={setPetType}>
                    <SelectTrigger id="pet-type" className="w-full">
                      <SelectValue placeholder="Select pet type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Dog">Dog</SelectItem>
                      <SelectItem value="Cat">Cat</SelectItem>
                      <SelectItem value="Bird">Bird</SelectItem>
                      <SelectItem value="Small Animal">Small Animal</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="breed">Breed</Label>
                  <Select value={breed} onValueChange={setBreed}>
                    <SelectTrigger id="breed" className="w-full">
                      <SelectValue placeholder="Select breed" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Labrador Retriever">Labrador Retriever</SelectItem>
                      <SelectItem value="German Shepherd">German Shepherd</SelectItem>
                      <SelectItem value="Golden Retriever">Golden Retriever</SelectItem>
                      <SelectItem value="French Bulldog">French Bulldog</SelectItem>
                      <SelectItem value="Beagle">Beagle</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="age">Age</Label>
                  <Select value={age} onValueChange={setAge}>
                    <SelectTrigger id="age" className="w-full">
                      <SelectValue placeholder="Select age" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Puppy (0-1 year)">Puppy (0-1 year)</SelectItem>
                      <SelectItem value="Young Adult (1-3 years)">Young Adult (1-3 years)</SelectItem>
                      <SelectItem value="Adult (3-7 years)">Adult (3-7 years)</SelectItem>
                      <SelectItem value="Senior (7+ years)">Senior (7+ years)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="category">Product Category</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger id="category" className="w-full">
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Food & Treats">Food & Treats</SelectItem>
                      <SelectItem value="Toys & Enrichment">Toys & Enrichment</SelectItem>
                      <SelectItem value="Health & Wellness">Health & Wellness</SelectItem>
                      <SelectItem value="Training Equipment">Training Equipment</SelectItem>
                      <SelectItem value="Grooming Supplies">Grooming Supplies</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Button className="w-full bg-accent hover:bg-accent/90 text-white">
                Find Perfect Products
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            {isLoading ? (
              Array(4).fill(0).map((_, i) => (
                <div key={i} className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm border border-gray-200 dark:border-gray-700 animate-pulse">
                  <div className="w-full h-40 bg-gray-200 dark:bg-gray-700"></div>
                  <div className="p-4">
                    <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mb-2"></div>
                    <div className="flex justify-between items-center mt-2">
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/3"></div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              products?.slice(0, 4).map(product => (
                <div key={product.id} className="bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
                  <img src={product.image} alt={product.name} className="w-full h-40 object-cover" />
                  <div className="p-4">
                    <h4 className="font-semibold dark:text-white">{product.name}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">{product.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-accent font-bold">${(product.price / 100).toFixed(2)}</span>
                      <a href={product.affiliateLink} target="_blank" rel="noopener noreferrer" className="text-sm text-primary font-medium">View Details</a>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductRecommendations;
