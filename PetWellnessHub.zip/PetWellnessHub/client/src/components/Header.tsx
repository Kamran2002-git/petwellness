import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/ThemeProvider";
import { Moon, Sun } from "lucide-react";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { theme, setTheme } = useTheme();
  const [rainbowActive, setRainbowActive] = useState(false);

  // Start rainbow animation every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setRainbowActive(true);
      setTimeout(() => setRainbowActive(false), 3000); // Run for 3 seconds
    }, 30000); // Every 30 seconds

    // Initial animation on load
    setRainbowActive(true);
    setTimeout(() => setRainbowActive(false), 3000);

    return () => clearInterval(interval);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <header className={`sticky top-0 z-50 shadow-md transition-all duration-300 ${
      rainbowActive 
        ? 'rainbow-animation' 
        : 'bg-white dark:bg-neutral-900'
    }`}>
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <Link href="/">
            <div className="flex items-center group">
              <i className="fas fa-paw text-primary text-3xl mr-2 transition-transform duration-300 group-hover:scale-110"></i>
              <span className="text-xl font-bold dark:text-white">
                PetPal<span className="text-primary animate-pulse">AI</span>
              </span>
            </div>
          </Link>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {[
            { href: "/#features", label: "Features" },
            { href: "/health", label: "Pet Health" },
            { href: "/training", label: "Training" },
            { href: "/blog", label: "Blog" },
            { href: "/pricing", label: "Pricing" }
          ].map((item, index) => (
            <Link 
              key={index} 
              href={item.href} 
              className={`font-medium hover:text-primary hover:scale-105 transition-all dark:text-gray-200 ${
                isActive(item.href) 
                  ? "text-primary font-semibold" 
                  : ""
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
        
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
            className="hidden md:flex hover:bg-primary/10 hover:scale-110 transition-all"
          >
            {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            <span className="sr-only">Toggle theme</span>
          </Button>
          
          <Link href="/chat">
            <Button 
              variant="outline" 
              className="hidden md:block hover:bg-primary/10 hover:border-primary transition-all"
            >
              Sign In
            </Button>
          </Link>
          
          <Link href="/chat">
            <Button 
              className="btn-hover-effect transition-all duration-300 hover:shadow-lg hover:scale-105"
            >
              Get Started
            </Button>
          </Link>
          
          <button
            className="md:hidden text-neutral-dark dark:text-gray-200 text-xl hover:text-primary transition-colors"
            onClick={toggleMobileMenu}
            aria-label="Toggle mobile menu"
          >
            <i className={`fas ${mobileMenuOpen ? "fa-times" : "fa-bars"}`}></i>
          </button>
        </div>
      </div>
      
      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-neutral-900 border-t dark:border-gray-800 shadow-lg animate-fadeIn">
          <div className="container mx-auto px-4 py-3 space-y-3">
            {[
              { href: "/#features", label: "Features" },
              { href: "/health", label: "Pet Health" },
              { href: "/training", label: "Training" },
              { href: "/blog", label: "Blog" },
              { href: "/pricing", label: "Pricing" },
              { href: "/chat", label: "Sign In", isPrimary: true }
            ].map((item, index) => (
              <Link 
                key={index} 
                href={item.href} 
                onClick={closeMobileMenu} 
                className={`block font-medium py-2 transition-all hover:translate-x-1 dark:text-gray-200 ${
                  item.isPrimary ? "text-primary" : "hover:text-primary"
                }`}
              >
                {item.label}
              </Link>
            ))}
            
            <div className="flex items-center py-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setTheme(theme === "light" ? "dark" : "light");
                }}
                className="flex items-center gap-2 hover:bg-primary/10 transition-all"
              >
                {theme === "light" ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                <span>{theme === "light" ? "Dark" : "Light"} Mode</span>
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
