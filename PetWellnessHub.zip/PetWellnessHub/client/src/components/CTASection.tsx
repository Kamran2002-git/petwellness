import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const CTASection = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-primary to-indigo-800 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Pet Care Experience?</h2>
          <p className="text-white/80 text-lg mb-8 max-w-2xl mx-auto">
            Join thousands of pet owners who are using AI to provide better care, training, and health management for their beloved companions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/chat">
              <Button size="lg" className="w-full sm:w-auto bg-white hover:bg-gray-100 text-primary">
                Get Started Free <i className="fas fa-arrow-right ml-2"></i>
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="w-full sm:w-auto border-white text-white hover:bg-white/10">
              See How It Works <i className="fas fa-play ml-2"></i>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
