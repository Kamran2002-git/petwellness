import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useEffect, useState, useRef } from "react";

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [typedText, setTypedText] = useState("");
  const [currentTip, setCurrentTip] = useState(0);
  const heroRef = useRef(null);
  const fullText = "Golden retrievers need 1-2 hours of exercise daily for optimal health.";
  
  const aiTips = [
    "Golden retrievers need 1-2 hours of exercise daily for optimal health.",
    "Cats typically sleep 12-16 hours per day to conserve energy.",
    "Regular dental care can extend your pet's life by 3-5 years!",
    "Training sessions should be limited to 15 minutes for puppies."
  ];
  
  // Typing effect for AI assistant message
  useEffect(() => {
    if (isVisible) {
      let currentIndex = 0;
      const textInterval = setInterval(() => {
        if (currentIndex < aiTips[currentTip].length) {
          setTypedText(aiTips[currentTip].substring(0, currentIndex + 1));
          currentIndex++;
        } else {
          clearInterval(textInterval);
          
          // Change tip after 5 seconds
          setTimeout(() => {
            setTypedText("");
            setCurrentTip((prev) => (prev + 1) % aiTips.length);
          }, 5000);
        }
      }, 50);
      
      return () => clearInterval(textInterval);
    }
  }, [isVisible, currentTip]);
  
  // Detect when hero section is in viewport
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting);
      },
      { threshold: 0.1 }
    );
    
    if (heroRef.current) {
      observer.observe(heroRef.current);
    }
    
    return () => {
      if (heroRef.current) {
        observer.unobserve(heroRef.current);
      }
    };
  }, []);

  return (
    <section 
      ref={heroRef}
      className="relative bg-gradient-to-r from-indigo-500/10 to-emerald-500/10 dark:from-indigo-950/30 dark:to-emerald-950/30 py-16 md:py-24 overflow-hidden"
    >
      {/* Animated background shapes */}
      <div className="absolute inset-0 overflow-hidden z-0">
        <div className="absolute top-20 left-10 w-32 h-32 bg-primary/10 rounded-full animate-float opacity-50"></div>
        <div className="absolute bottom-10 right-10 w-40 h-40 bg-secondary/10 rounded-full animate-float-delay opacity-50"></div>
        <div className="absolute top-40 right-20 w-24 h-24 bg-accent/10 rounded-full animate-float-slow opacity-40"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 dark:text-white">
              AI-Powered <span className="text-primary animate-pulse">Pet Health</span> & <span className="text-secondary">Training</span> Assistant
            </h1>
            <p className="text-lg mb-8 text-gray-600 dark:text-gray-300">
              Get personalized health advice, training plans, and product recommendations for your furry friends from our advanced AI assistant.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <Link href="/chat">
                <Button 
                  size="lg" 
                  className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-white pulse-animation shadow-lg"
                >
                  Ask Virtual Vet <i className="fas fa-stethoscope ml-2"></i>
                </Button>
              </Link>
              <Link href="/training">
                <Button 
                  size="lg" 
                  className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white btn-hover-effect"
                >
                  Training Coach <i className="fas fa-graduation-cap ml-2"></i>
                </Button>
              </Link>
            </div>
            <div className="flex flex-wrap items-center text-sm text-gray-500 dark:text-gray-400 gap-4">
              {["Vet-approved advice", "24/7 availability", "Personalized plans"].map((item, index) => (
                <span 
                  key={index} 
                  className="flex items-center transition-all hover:scale-105"
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  <i className="fas fa-check-circle text-secondary mr-2 animate-pulse"></i> {item}
                </span>
              ))}
            </div>
          </div>
          <div className={`relative h-[400px] rounded-xl overflow-hidden shadow-xl transition-all duration-700 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`}>
            <img 
              src="https://images.unsplash.com/photo-1530281700549-e82e7bf110d6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Happy dog with tennis ball" 
              className="w-full h-full object-cover rounded-xl hover:scale-105 transition-transform duration-700" 
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-neutral-dark/80 to-transparent p-6">
              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg max-w-xs hover-lift">
                <div className="flex items-start space-x-3">
                  <div className="bg-primary/20 dark:bg-primary/30 rounded-full p-2 animate-pulse">
                    <i className="fas fa-robot text-primary text-lg"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-neutral-dark dark:text-gray-200">PetPal AI Assistant</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 h-10">
                      {typedText}
                      <span className="animate-pulse">|</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative element */}
      <div className="hidden md:block absolute bottom-0 left-0 right-0 h-6 bg-white dark:bg-gray-900 clip-path-wave z-20"></div>
    </section>
  );
};

export default Hero;
