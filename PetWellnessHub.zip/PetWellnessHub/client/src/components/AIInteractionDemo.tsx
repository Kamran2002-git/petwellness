import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";

const AIInteractionDemo = () => {
  const [userInput, setUserInput] = useState("");
  
  // Example chat messages for the demo
  const chatMessages = [
    { role: "assistant", content: "Hello! I'm your PetPal AI assistant. How can I help with your pet today?" },
    { role: "user", content: "My dog has been scratching his ears a lot. Should I be concerned?" },
    { role: "assistant", content: "Frequent ear scratching could indicate an ear infection, allergies, or ear mites. Key things to check:\n- Is there redness or swelling?\n- Do you notice any discharge or odor?\n- Is your dog tilting their head to one side?\n\nWould you like me to recommend some solutions based on these symptoms?" },
    { role: "user", content: "Yes, I've noticed some redness and he keeps tilting his head." },
    { role: "assistant", content: "Those symptoms suggest your dog may have an ear infection. Here's what you can do:\n\n1. Schedule a vet visit - ear infections typically require prescription medication\n2. In the meantime, avoid getting water in the ears\n3. Don't insert anything into the ear canal\n\nWould you like to book a virtual vet consultation for a professional diagnosis?" },
  ];

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4 dark:text-white">See PetPal AI in Action</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Experience how our AI assistant provides helpful advice for your pet's health and training needs.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg p-6 h-[500px] flex flex-col">
            <div className="flex items-center justify-between mb-4 pb-4 border-b dark:border-gray-700">
              <div className="flex items-center">
                <div className="bg-primary/10 dark:bg-primary/20 rounded-full p-2 mr-3">
                  <i className="fas fa-robot text-primary"></i>
                </div>
                <div>
                  <h3 className="font-semibold dark:text-white">Virtual Vet Assistant</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Powered by PetPal AI</p>
                </div>
              </div>
              <button className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
                <i className="fas fa-ellipsis-v"></i>
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto mb-4 space-y-4">
              {chatMessages.map((message, index) => (
                message.role === "assistant" ? (
                  <div key={index} className="flex items-start">
                    <div className="bg-primary/10 dark:bg-primary/20 rounded-full p-2 mr-3">
                      <i className="fas fa-robot text-primary text-sm"></i>
                    </div>
                    <div className="bg-gray-100 dark:bg-gray-800 p-3 rounded-lg chat-bubble-ai max-w-[80%]">
                      <p className="text-sm whitespace-pre-line dark:text-gray-300">{message.content}</p>
                      {index === chatMessages.length - 1 && (
                        <div className="mt-3 p-3 bg-white dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600">
                          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400">RECOMMENDED PRODUCTS</p>
                          <div className="flex items-center mt-2 text-sm">
                            <div className="w-12 h-12 bg-gray-200 dark:bg-gray-600 rounded-md mr-3"></div>
                            <div>
                              <p className="font-medium dark:text-white">Gentle Ear Cleaner Solution</p>
                              <p className="text-accent text-xs">View on PetStore →</p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div key={index} className="flex items-start justify-end">
                    <div className="bg-primary p-3 rounded-lg chat-bubble-user text-white max-w-[80%]">
                      <p className="text-sm">{message.content}</p>
                    </div>
                  </div>
                )
              ))}
            </div>
            
            <div className="border-t pt-4 dark:border-gray-700">
              <div className="flex items-center">
                <Input
                  type="text"
                  placeholder="Type your question here..."
                  className="rounded-r-none focus:ring-primary"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                />
                <Button className="rounded-l-none bg-primary hover:bg-primary/90">
                  <i className="fas fa-paper-plane"></i>
                </Button>
              </div>
              <div className="flex justify-between mt-2 text-xs text-gray-500 dark:text-gray-400">
                <span>Powered by AI - Not a substitute for professional veterinary advice</span>
                <button className="text-primary">Clear conversation</button>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-bold mb-6 dark:text-white">How Our AI Helps Your Pet</h3>
            
            <div className="space-y-6">
              {/* Feature 1 */}
              <div className="flex items-start">
                <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full p-2 mr-4 mt-1">
                  <i className="fas fa-check text-emerald-600 dark:text-emerald-400"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-2 dark:text-white">24/7 Instant Support</h4>
                  <p className="text-gray-600 dark:text-gray-300">
                    Get immediate answers to your pet health questions anytime, anywhere without waiting for a vet appointment.
                  </p>
                </div>
              </div>
              
              {/* Feature 2 */}
              <div className="flex items-start">
                <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full p-2 mr-4 mt-1">
                  <i className="fas fa-check text-emerald-600 dark:text-emerald-400"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-2 dark:text-white">Personalized Care</h4>
                  <p className="text-gray-600 dark:text-gray-300">
                    Our AI remembers your pet's details to provide tailored advice specific to their breed, age, and health history.
                  </p>
                </div>
              </div>
              
              {/* Feature 3 */}
              <div className="flex items-start">
                <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full p-2 mr-4 mt-1">
                  <i className="fas fa-check text-emerald-600 dark:text-emerald-400"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-2 dark:text-white">Product Recommendations</h4>
                  <p className="text-gray-600 dark:text-gray-300">
                    Get suggestions for vet-approved products that address your pet's specific needs and health concerns.
                  </p>
                </div>
              </div>
              
              {/* Feature 4 */}
              <div className="flex items-start">
                <div className="bg-emerald-100 dark:bg-emerald-900/30 rounded-full p-2 mr-4 mt-1">
                  <i className="fas fa-check text-emerald-600 dark:text-emerald-400"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-lg mb-2 dark:text-white">Training Assistance</h4>
                  <p className="text-gray-600 dark:text-gray-300">
                    Access step-by-step training plans customized to your pet's behavior challenges and learning style.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <Link href="/chat">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-white">
                  Try PetPal AI Now <i className="fas fa-arrow-right ml-2"></i>
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIInteractionDemo;
