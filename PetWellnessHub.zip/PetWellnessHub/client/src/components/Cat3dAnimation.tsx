import { useState, useEffect, useRef } from 'react';

const Cat3dAnimation = () => {
  const [visible, setVisible] = useState(true);
  const [stage, setStage] = useState<'entering' | 'waving' | 'leaving'>('entering');
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const catRef = useRef<HTMLDivElement>(null);

  // Track mouse movement for 3D effect
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!catRef.current) return;
      
      const rect = catRef.current.getBoundingClientRect();
      const catCenterX = rect.left + rect.width / 2;
      const catCenterY = rect.top + rect.height / 2;
      
      // Calculate normalized position relative to cat (values between -1 and 1)
      const normalizedX = (e.clientX - catCenterX) / (window.innerWidth / 2);
      const normalizedY = (e.clientY - catCenterY) / (window.innerHeight / 2);
      
      setMousePosition({ 
        x: normalizedX * 10, // Max 10 degrees rotation
        y: normalizedY * 10  // Max 10 degrees rotation
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  // Animation sequence
  useEffect(() => {
    // Start waving after 1.5 seconds
    const waveTimer = setTimeout(() => {
      setStage('waving');
    }, 1500);

    // Start leaving animation after 8 seconds
    const leaveTimer = setTimeout(() => {
      setStage('leaving');
    }, 8000);
    
    // Hide component after 10 seconds
    const hideTimer = setTimeout(() => {
      setVisible(false);
    }, 10000);

    return () => {
      clearTimeout(waveTimer);
      clearTimeout(leaveTimer);
      clearTimeout(hideTimer);
    };
  }, []);

  if (!visible) return null;

  return (
    <div 
      className={`fixed bottom-5 right-5 z-50 transition-all duration-1000 ${
        stage === 'entering' ? 'translate-y-0 opacity-100 scale-100' :
        stage === 'waving' ? 'translate-y-0 opacity-100 scale-100' :
        'translate-y-[200px] opacity-0 scale-90'
      }`}
    >
      <div 
        ref={catRef}
        className="relative w-64 h-64 transform-style-3d perspective-800"
        style={{
          transform: `rotateX(${-mousePosition.y}deg) rotateY(${mousePosition.x}deg)`
        }}
      >
        {/* 3D Cat */}
        <div className="cat-container absolute w-48 h-48 transform-style-3d">
          {/* Body - Main sphere */}
          <div className="absolute w-40 h-40 bg-gradient-to-b from-gray-300 to-gray-400 dark:from-gray-500 dark:to-gray-600 rounded-full bottom-0 left-4 shadow-lg transform-style-3d z-20">
            {/* Belly */}
            <div className="absolute w-32 h-32 bg-gradient-to-b from-gray-200 to-gray-300 dark:from-gray-400 dark:to-gray-500 rounded-full bottom-0 left-4 transform translate-z-2"></div>
            
            {/* Face */}
            <div className="absolute w-36 h-36 bg-gradient-to-b from-gray-300 to-gray-400 dark:from-gray-500 dark:to-gray-600 rounded-full top-[-20px] left-2 transform-style-3d translate-z-5">
              {/* Eyes */}
              <div className="absolute w-5 h-7 bg-gray-900 rounded-full top-12 left-8 transform translate-z-2"></div>
              <div className="absolute w-5 h-7 bg-gray-900 rounded-full top-12 right-8 transform translate-z-2"></div>
              
              {/* Eye shine */}
              <div className="absolute w-2 h-2 bg-white rounded-full top-13 left-9 transform translate-z-3"></div>
              <div className="absolute w-2 h-2 bg-white rounded-full top-13 right-9 transform translate-z-3"></div>

              {/* Blinking animation */}
              <div className={`absolute w-5 h-7 bg-gradient-to-b from-gray-300 to-gray-400 dark:from-gray-500 dark:to-gray-600 rounded-full top-12 left-8 transform translate-z-3 transition-all ${stage === 'waving' ? 'animate-blink' : ''}`}></div>
              <div className={`absolute w-5 h-7 bg-gradient-to-b from-gray-300 to-gray-400 dark:from-gray-500 dark:to-gray-600 rounded-full top-12 right-8 transform translate-z-3 transition-all ${stage === 'waving' ? 'animate-blink-delay' : ''}`}></div>

              {/* Nose */}
              <div className="absolute w-4 h-3 bg-pink-300 dark:bg-pink-400 rounded-full top-20 left-16 transform translate-z-6"></div>
              
              {/* Mouth */}
              <div className="absolute w-10 h-4 border-b-2 border-gray-700 rounded-b-full top-22 left-13 transform translate-z-4"></div>
              
              {/* Whiskers */}
              <div className="absolute w-12 h-0.5 bg-gray-600 top-20 left-[-8px] transform rotate-[-15deg] translate-z-3"></div>
              <div className="absolute w-12 h-0.5 bg-gray-600 top-22 left-[-10px] transform rotate-[-5deg] translate-z-3"></div>
              <div className="absolute w-12 h-0.5 bg-gray-600 top-20 right-[-8px] transform rotate-[15deg] translate-z-3"></div>
              <div className="absolute w-12 h-0.5 bg-gray-600 top-22 right-[-10px] transform rotate-[5deg] translate-z-3"></div>
              
              {/* Ears */}
              <div className="absolute w-14 h-14 transform-style-3d">
                <div className="absolute w-12 h-12 bg-gradient-to-b from-gray-300 to-gray-400 dark:from-gray-500 dark:to-gray-600 left-2 top-[-8px] transform rotate-[-30deg] origin-bottom-right rounded-tl-[80%] translate-z-[-5px]">
                  <div className="absolute w-8 h-8 bg-gradient-to-b from-pink-200 to-pink-300 dark:from-pink-300 dark:to-pink-400 left-1 top-1 transform rotate-[-5deg] origin-bottom-right rounded-tl-[80%] translate-z-1"></div>
                </div>
              </div>
              <div className="absolute w-14 h-14 transform-style-3d right-0">
                <div className="absolute w-12 h-12 bg-gradient-to-b from-gray-300 to-gray-400 dark:from-gray-500 dark:to-gray-600 right-2 top-[-8px] transform rotate-[30deg] origin-bottom-left rounded-tr-[80%] translate-z-[-5px]">
                  <div className="absolute w-8 h-8 bg-gradient-to-b from-pink-200 to-pink-300 dark:from-pink-300 dark:to-pink-400 right-1 top-1 transform rotate-[5deg] origin-bottom-left rounded-tr-[80%] translate-z-1"></div>
                </div>
              </div>
            </div>
            
            {/* Waving paw */}
            <div 
              className={`absolute w-12 h-18 bg-gradient-to-b from-gray-200 to-gray-300 dark:from-gray-400 dark:to-gray-500 rounded-full top-8 right-[-10px] transform-style-3d translate-z-8 origin-top ${
                stage === 'waving' ? 'animate-wave' : ''
              }`}
            >
              {/* Paw pads */}
              <div className="absolute w-4 h-3 bg-pink-300 dark:bg-pink-400 rounded-full bottom-2 left-2 transform translate-z-1"></div>
              <div className="absolute w-4 h-3 bg-pink-300 dark:bg-pink-400 rounded-full bottom-2 right-2 transform translate-z-1"></div>
              <div className="absolute w-4 h-3 bg-pink-300 dark:bg-pink-400 rounded-full bottom-6 left-4 transform translate-z-1"></div>
            </div>
            
            {/* Tail */}
            <div className="absolute w-12 h-40 bg-gradient-to-b from-gray-300 to-gray-400 dark:from-gray-500 dark:to-gray-600 rounded-full bottom-2 left-[-16px] transform-style-3d translate-z-[-10px] origin-bottom rotate-[20deg] animate-tail-sway"></div>
          </div>
        </div>

        {/* Speech bubble with 3D effect */}
        <div 
          className={`absolute right-32 bottom-32 bg-white dark:bg-gray-800 p-4 rounded-2xl shadow-xl 
            transform-style-3d translate-z-20 transition-all duration-500 
            ${stage === 'waving' ? 'opacity-100 scale-100 rotate-2' : 'opacity-0 scale-95 -rotate-2'}`}
          style={{ boxShadow: '0 10px 25px rgba(0,0,0,0.2)' }}
        >
          <div className="absolute bottom-[-10px] right-4 w-6 h-6 bg-white dark:bg-gray-800 transform rotate-45 shadow-b"></div>
          <p className="text-md font-medium text-gray-800 dark:text-gray-200 transform translate-z-5">
            <span className="block mb-1">Meow! Welcome to PetPalAI!</span>
            <span className="text-xs text-gray-500">Your furry friend's health companion</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Cat3dAnimation;