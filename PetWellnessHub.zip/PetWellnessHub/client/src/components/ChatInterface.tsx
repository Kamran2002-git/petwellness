import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useChat } from "@/hooks/useChat";

const ChatInterface = () => {
  const [category, setCategory] = useState<"health" | "training" | "product">("health");
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const { messages, isLoading, sendMessage } = useChat();
  
  // Scroll to bottom whenever messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    sendMessage(message, category);
    setMessage("");
  };
  
  const handleClearChat = () => {
    window.location.reload();
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl shadow-lg h-[600px] flex flex-col">
      <Tabs defaultValue="health" onValueChange={(value) => setCategory(value as "health" | "training" | "product")}>
        <div className="border-b dark:border-gray-700 px-6 py-3">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center">
              <div className="bg-primary/10 dark:bg-primary/20 rounded-full p-2 mr-3">
                <i className="fas fa-robot text-primary"></i>
              </div>
              <div>
                <h3 className="font-semibold dark:text-white">PetPal AI Assistant</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400">Powered by advanced AI</p>
              </div>
            </div>
            <button 
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
              onClick={handleClearChat}
              aria-label="Clear conversation"
            >
              <i className="fas fa-trash-alt"></i>
            </button>
          </div>
          
          <TabsList className="w-full">
            <TabsTrigger value="health" className="flex-1">
              <i className="fas fa-stethoscope mr-2"></i> Health
            </TabsTrigger>
            <TabsTrigger value="training" className="flex-1">
              <i className="fas fa-graduation-cap mr-2"></i> Training
            </TabsTrigger>
            <TabsTrigger value="product" className="flex-1">
              <i className="fas fa-shopping-cart mr-2"></i> Products
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="health" className="flex-1 flex flex-col">
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="bg-primary/10 dark:bg-primary/20 rounded-full p-4 mb-4">
                  <i className="fas fa-stethoscope text-primary text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold mb-2 dark:text-white">Ask the Virtual Vet</h3>
                <p className="text-gray-600 dark:text-gray-300 max-w-md">
                  Get answers to pet health questions, symptom assessment, and care recommendations.
                </p>
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-2 w-full max-w-md">
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("My dog is vomiting, what should I do?")}>
                    <i className="fas fa-question-circle mr-2 text-primary"></i> Dog vomiting
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("My cat isn't eating, should I be worried?")}>
                    <i className="fas fa-question-circle mr-2 text-primary"></i> Cat not eating
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("What vaccinations does my puppy need?")}>
                    <i className="fas fa-question-circle mr-2 text-primary"></i> Puppy vaccines
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("How do I treat my dog's itchy skin?")}>
                    <i className="fas fa-question-circle mr-2 text-primary"></i> Itchy skin
                  </Button>
                </div>
              </div>
            ) : (
              messages.map((msg, index) => (
                <div key={index} className={`flex items-start ${msg.role === "user" ? "justify-end" : ""}`}>
                  {msg.role === "assistant" && (
                    <div className="bg-primary/10 dark:bg-primary/20 rounded-full p-2 mr-3 mt-1">
                      <i className="fas fa-robot text-primary text-sm"></i>
                    </div>
                  )}
                  <div 
                    className={`p-3 rounded-lg max-w-[80%] ${
                      msg.role === "user" 
                        ? "bg-primary text-white chat-bubble-user" 
                        : "bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 chat-bubble-ai"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-line">{msg.content}</p>
                    {msg.productRecommendation && (
                      <div className="mt-3 p-3 bg-white dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600">
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400">RECOMMENDED PRODUCTS</p>
                        <div className="flex items-center mt-2 text-sm">
                          <div className="bg-primary/10 dark:bg-primary/20 rounded-full p-2 mr-3">
                            <i className="fas fa-tag text-primary text-sm"></i>
                          </div>
                          <div>
                            <p className="font-medium dark:text-white">{msg.productRecommendation.title}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{msg.productRecommendation.description}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
        </TabsContent>
        
        <TabsContent value="training" className="flex-1 flex flex-col">
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="bg-secondary/10 dark:bg-secondary/20 rounded-full p-4 mb-4">
                  <i className="fas fa-graduation-cap text-secondary text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold mb-2 dark:text-white">Training Coach</h3>
                <p className="text-gray-600 dark:text-gray-300 max-w-md">
                  Get step-by-step training guides tailored to your pet's breed, age, and behavior challenges.
                </p>
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-2 w-full max-w-md">
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("How do I stop my dog from barking at night?")}>
                    <i className="fas fa-question-circle mr-2 text-secondary"></i> Stop barking
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("How do I train my puppy to walk on a leash?")}>
                    <i className="fas fa-question-circle mr-2 text-secondary"></i> Leash training
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("My cat scratches furniture, how do I stop it?")}>
                    <i className="fas fa-question-circle mr-2 text-secondary"></i> Scratch training
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("How to potty train a new puppy?")}>
                    <i className="fas fa-question-circle mr-2 text-secondary"></i> Potty training
                  </Button>
                </div>
              </div>
            ) : (
              messages.map((msg, index) => (
                <div key={index} className={`flex items-start ${msg.role === "user" ? "justify-end" : ""}`}>
                  {msg.role === "assistant" && (
                    <div className="bg-secondary/10 dark:bg-secondary/20 rounded-full p-2 mr-3 mt-1">
                      <i className="fas fa-graduation-cap text-secondary text-sm"></i>
                    </div>
                  )}
                  <div 
                    className={`p-3 rounded-lg max-w-[80%] ${
                      msg.role === "user" 
                        ? "bg-primary text-white chat-bubble-user" 
                        : "bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 chat-bubble-ai"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-line">{msg.content}</p>
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
        </TabsContent>
        
        <TabsContent value="product" className="flex-1 flex flex-col">
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="bg-accent/10 dark:bg-accent/20 rounded-full p-4 mb-4">
                  <i className="fas fa-shopping-cart text-accent text-2xl"></i>
                </div>
                <h3 className="text-xl font-semibold mb-2 dark:text-white">Product Recommendations</h3>
                <p className="text-gray-600 dark:text-gray-300 max-w-md">
                  Get personalized product suggestions based on your pet's needs and preferences.
                </p>
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-2 w-full max-w-md">
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("What's the best food for a German Shepherd puppy?")}>
                    <i className="fas fa-question-circle mr-2 text-accent"></i> Puppy food
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("Recommend toys for a high-energy dog")}>
                    <i className="fas fa-question-circle mr-2 text-accent"></i> Dog toys
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("What brush should I use for my long-haired cat?")}>
                    <i className="fas fa-question-circle mr-2 text-accent"></i> Cat grooming
                  </Button>
                  <Button variant="outline" className="justify-start" onClick={() => setMessage("Best treats for training a new puppy?")}>
                    <i className="fas fa-question-circle mr-2 text-accent"></i> Training treats
                  </Button>
                </div>
              </div>
            ) : (
              messages.map((msg, index) => (
                <div key={index} className={`flex items-start ${msg.role === "user" ? "justify-end" : ""}`}>
                  {msg.role === "assistant" && (
                    <div className="bg-accent/10 dark:bg-accent/20 rounded-full p-2 mr-3 mt-1">
                      <i className="fas fa-shopping-cart text-accent text-sm"></i>
                    </div>
                  )}
                  <div 
                    className={`p-3 rounded-lg max-w-[80%] ${
                      msg.role === "user" 
                        ? "bg-primary text-white chat-bubble-user" 
                        : "bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 chat-bubble-ai"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-line">{msg.content}</p>
                    {msg.productRecommendation && (
                      <div className="mt-3 p-3 bg-white dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600">
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400">RECOMMENDED PRODUCTS</p>
                        <div className="flex items-center mt-2 text-sm">
                          <div className="bg-accent/10 dark:bg-accent/20 rounded-full p-2 mr-3">
                            <i className="fas fa-tag text-accent text-sm"></i>
                          </div>
                          <div>
                            <p className="font-medium dark:text-white">{msg.productRecommendation.title}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{msg.productRecommendation.description}</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>
        </TabsContent>
      </Tabs>
      
      <div className="border-t dark:border-gray-700 p-4">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          <Input
            type="text"
            placeholder="Type your question here..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={isLoading}
            className="flex-1"
          />
          <Button type="submit" disabled={isLoading || !message.trim()} className="bg-primary hover:bg-primary/90">
            {isLoading ? (
              <i className="fas fa-spinner fa-spin"></i>
            ) : (
              <i className="fas fa-paper-plane"></i>
            )}
          </Button>
        </form>
        <div className="flex justify-between mt-2 text-xs text-gray-500 dark:text-gray-400">
          <span>Powered by AI - Not a substitute for professional veterinary advice</span>
          <button className="text-primary" onClick={handleClearChat}>Clear conversation</button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
