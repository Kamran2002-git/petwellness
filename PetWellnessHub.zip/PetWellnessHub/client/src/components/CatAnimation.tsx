import { useState, useEffect } from 'react';

const CatAnimation = () => {
  const [visible, setVisible] = useState(true);
  const [waving, setWaving] = useState(false);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    // Start waving after 1 second
    const waveTimer = setTimeout(() => {
      setWaving(true);
    }, 1000);

    // Start leaving animation after 8 seconds
    const leaveTimer = setTimeout(() => {
      setLeaving(true);
    }, 8000);
    
    // Hide component after 10 seconds
    const hideTimer = setTimeout(() => {
      setVisible(false);
    }, 10000);

    return () => {
      clearTimeout(waveTimer);
      clearTimeout(leaveTimer);
      clearTimeout(hideTimer);
    };
  }, []);

  if (!visible) return null;

  return (
    <div 
      className={`fixed bottom-5 right-5 z-50 transition-all duration-1000 ${
        leaving ? 'translate-y-[200px] opacity-0' : 'translate-y-0 opacity-100'
      }`}
    >
      <div className="relative w-48 h-48">
        {/* Cat body */}
        <div className="absolute w-40 h-32 bg-gray-300 dark:bg-gray-500 rounded-[50%] bottom-0 left-4 overflow-hidden shadow-lg">
          {/* Belly */}
          <div className="absolute w-28 h-22 bg-gray-200 dark:bg-gray-400 rounded-[50%] bottom-0 left-6"></div>

          {/* Face */}
          <div className="absolute w-28 h-24 bg-gray-300 dark:bg-gray-500 rounded-[50%] top-[-12px] left-6 z-10">
            {/* Eyes */}
            <div className="absolute w-4 h-6 bg-black rounded-full top-8 left-6"></div>
            <div className="absolute w-4 h-6 bg-black rounded-full top-8 right-6"></div>

            {/* Blinking animation */}
            <div className={`absolute w-4 h-6 bg-gray-300 dark:bg-gray-500 rounded-full top-8 left-6 transition-all ${waving ? 'animate-blink' : ''}`}></div>
            <div className={`absolute w-4 h-6 bg-gray-300 dark:bg-gray-500 rounded-full top-8 right-6 transition-all ${waving ? 'animate-blink-delay' : ''}`}></div>

            {/* Nose */}
            <div className="absolute w-3 h-2 bg-pink-300 rounded-full top-14 left-[12.5px] mx-auto"></div>

            {/* Mouth */}
            <div className="absolute w-8 h-3 border-b-2 border-black rounded-b-full top-16 left-10"></div>

            {/* Whiskers */}
            <div className="absolute w-10 h-1 border-t border-gray-600 top-14 left-[-6px] transform rotate-[-10deg]"></div>
            <div className="absolute w-10 h-1 border-t border-gray-600 top-16 left-[-8px] transform rotate-[-5deg]"></div>
            <div className="absolute w-10 h-1 border-t border-gray-600 top-14 right-[-6px] transform rotate-[10deg]"></div>
            <div className="absolute w-10 h-1 border-t border-gray-600 top-16 right-[-8px] transform rotate-[5deg]"></div>

            {/* Ears */}
            <div className="absolute w-10 h-10 bg-gray-300 dark:bg-gray-500 left-[-2px] top-[-8px] transform rotate-[-30deg] origin-bottom-right rounded-tl-[80%]">
              <div className="absolute w-6 h-6 bg-pink-200 dark:bg-pink-300 left-1 top-1 transform rotate-[-5deg] origin-bottom-right rounded-tl-[80%]"></div>
            </div>
            <div className="absolute w-10 h-10 bg-gray-300 dark:bg-gray-500 right-[-2px] top-[-8px] transform rotate-[30deg] origin-bottom-left rounded-tr-[80%]">
              <div className="absolute w-6 h-6 bg-pink-200 dark:bg-pink-300 right-1 top-1 transform rotate-[5deg] origin-bottom-left rounded-tr-[80%]"></div>
            </div>
          </div>

          {/* Waving paw */}
          <div 
            className={`absolute w-10 h-16 bg-gray-200 dark:bg-gray-400 rounded-full top-6 right-[-8px] z-20 origin-top ${
              waving ? 'animate-wave' : ''
            }`}
          >
            {/* Paw pads */}
            <div className="absolute w-3 h-2 bg-pink-300 rounded-full bottom-1 left-1"></div>
            <div className="absolute w-3 h-2 bg-pink-300 rounded-full bottom-1 right-1"></div>
            <div className="absolute w-3 h-2 bg-pink-300 rounded-full bottom-4 left-3.5"></div>
          </div>

          {/* Tail */}
          <div className="absolute w-10 h-32 bg-gray-300 dark:bg-gray-500 rounded-full bottom-1 left-[-14px] z-[-1] origin-bottom transform rotate-[20deg] animate-tail-sway"></div>
        </div>
      </div>

      {/* Speech bubble */}
      <div className={`absolute right-32 bottom-32 bg-white dark:bg-gray-800 p-3 rounded-2xl shadow-md 
        transition-all duration-500 ${waving ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
        <div className="absolute bottom-[-10px] right-4 w-6 h-6 bg-white dark:bg-gray-800 transform rotate-45"></div>
        <p className="text-sm font-medium text-gray-800 dark:text-gray-200">Hello! Welcome to PetPalAI!</p>
      </div>
    </div>
  );
};

export default CatAnimation;