import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trainingChallenges } from "@/lib/petData";

const Training = () => {
  // Set page title and meta description
  useEffect(() => {
    document.title = "Pet Training Coach | PetPal AI";
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Get personalized step-by-step training plans tailored to your pet's breed, age, and specific behavior challenges with our AI Training Coach.");
    }
  }, []);

  const [petType, setPetType] = useState<"dog" | "cat">("dog");

  return (
    <div className="bg-gradient-to-r from-indigo-500/10 to-emerald-500/10 dark:from-indigo-950/30 dark:to-emerald-950/30 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-secondary font-semibold">PET TRAINING</span>
          <h1 className="text-3xl font-bold mt-2 mb-4 dark:text-white">Personalized Training Plans</h1>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Our AI training coach creates custom training plans tailored to your pet's breed, age, and specific behavior challenges.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            {/* A professional dog trainer working with a dog */}
            <img 
              src="https://images.unsplash.com/photo-1551730459-92db2a308d6a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Professional dog training session" 
              className="rounded-xl shadow-lg w-full h-auto" 
            />
            
            <div className="mt-6 grid grid-cols-3 gap-4">
              {/* A pet owner training a puppy with positive reinforcement */}
              <img 
                src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200" 
                alt="Puppy training with positive reinforcement" 
                className="rounded-lg shadow-md h-32 object-cover" 
              />
              
              {/* A cat learning to use a training target */}
              <img 
                src="https://images.unsplash.com/photo-1574158622682-e40e69881006?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200" 
                alt="Cat with training target" 
                className="rounded-lg shadow-md h-32 object-cover" 
              />
              
              {/* A dog performing an obedience command */}
              <img 
                src="https://images.unsplash.com/photo-1591946614720-90a587da4a36?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=300&h=200" 
                alt="Dog performing obedience command" 
                className="rounded-lg shadow-md h-32 object-cover" 
              />
            </div>
          </div>
          
          <div className="order-1 md:order-2">
            <h2 className="text-2xl font-bold mb-6 dark:text-white">AI Training Coach Features</h2>
            
            <div className="space-y-6">
              {/* Feature 1 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
                <div className="flex items-start">
                  <div className="bg-secondary/10 dark:bg-secondary/20 rounded-full p-2 mr-4 mt-1">
                    <i className="fas fa-paw text-secondary"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2 dark:text-white">Breed-Specific Training</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      Training methods optimized for your pet's breed characteristics, learning style, and natural instincts.
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Feature 2 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
                <div className="flex items-start">
                  <div className="bg-secondary/10 dark:bg-secondary/20 rounded-full p-2 mr-4 mt-1">
                    <i className="fas fa-book text-secondary"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2 dark:text-white">Step-by-Step Guides</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      Clear, easy-to-follow instructions with video demonstrations for each training technique.
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Feature 3 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
                <div className="flex items-start">
                  <div className="bg-secondary/10 dark:bg-secondary/20 rounded-full p-2 mr-4 mt-1">
                    <i className="fas fa-chart-line text-secondary"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2 dark:text-white">Progress Tracking</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      Monitor your pet's training progress and get recommendations for advancing to the next level.
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Feature 4 */}
              <div className="bg-white dark:bg-gray-800 rounded-xl p-5 shadow-sm">
                <div className="flex items-start">
                  <div className="bg-secondary/10 dark:bg-secondary/20 rounded-full p-2 mr-4 mt-1">
                    <i className="fas fa-comment-dots text-secondary"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg mb-2 dark:text-white">Behavior Solutions</h3>
                    <p className="text-gray-600 dark:text-gray-300">
                      Custom plans to address specific behavior issues like barking, chewing, or separation anxiety.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-8">
              <Link href="/chat">
                <Button size="lg" className="bg-secondary hover:bg-secondary/90 text-white">
                  Get Your Training Plan <i className="fas fa-arrow-right ml-2"></i>
                </Button>
              </Link>
            </div>
          </div>
        </div>
        
        <div className="mt-20">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold mb-4 dark:text-white">Common Training Challenges</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Select your pet type and explore solutions for common training issues.
            </p>
          </div>
          
          <Tabs defaultValue="dog" onValueChange={(value) => setPetType(value as "dog" | "cat")}>
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="dog" className="px-8">
                  <i className="fas fa-dog mr-2"></i> Dogs
                </TabsTrigger>
                <TabsTrigger value="cat" className="px-8">
                  <i className="fas fa-cat mr-2"></i> Cats
                </TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="dog">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {trainingChallenges.dog.map((challenge, index) => (
                  <Card key={index} className="bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="bg-secondary/10 dark:bg-secondary/20 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                        <i className="fas fa-graduation-cap text-secondary text-xl"></i>
                      </div>
                      <h3 className="text-lg font-semibold mb-2 dark:text-white">{challenge}</h3>
                      <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                        Get step-by-step training guidance to address this common behavior challenge.
                      </p>
                      <Link href={`/chat?message=How do I train my dog to stop ${challenge.toLowerCase()}?&category=training`}>
                        <Button variant="outline" className="w-full">Get Solutions</Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="cat">
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {trainingChallenges.cat.map((challenge, index) => (
                  <Card key={index} className="bg-white dark:bg-gray-800 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="bg-secondary/10 dark:bg-secondary/20 w-12 h-12 rounded-full flex items-center justify-center mb-4">
                        <i className="fas fa-graduation-cap text-secondary text-xl"></i>
                      </div>
                      <h3 className="text-lg font-semibold mb-2 dark:text-white">{challenge}</h3>
                      <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                        Get step-by-step training guidance to address this common behavior challenge.
                      </p>
                      <Link href={`/chat?message=How do I train my cat to stop ${challenge.toLowerCase()}?&category=training`}>
                        <Button variant="outline" className="w-full">Get Solutions</Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="mt-20 text-center">
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Ready to Start Training?</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-8">
            Get personalized training advice from our AI coach tailored specifically to your pet's needs.
          </p>
          <Link href="/chat">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white">
              Chat with Training Coach Now <i className="fas fa-comment-dots ml-2"></i>
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Training;
