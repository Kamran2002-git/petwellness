import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckIcon, XIcon } from "lucide-react";

const Pricing = () => {
  // Set page title and meta description
  useEffect(() => {
    document.title = "Pricing Plans | PetPal AI";
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Choose the perfect plan for your pet. Access our AI-powered pet care platform with plans that fit your needs and budget.");
    }
  }, []);

  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  
  // Features for each plan
  const freePlanFeatures = [
    { name: "Limited AI chat interactions", included: true },
    { name: "Basic symptom checker", included: true },
    { name: "General training tips", included: true },
    { name: "Access to blog articles", included: true },
    { name: "Personalized training plans", included: false },
    { name: "Health history tracking", included: false },
  ];
  
  const premiumPlanFeatures = [
    { name: "Unlimited AI interactions", included: true },
    { name: "Advanced symptom analysis", included: true },
    { name: "Personalized training plans", included: true },
    { name: "Health history tracking", included: true },
    { name: "Custom product recommendations", included: true },
    { name: "Priority vet consultations", included: false },
  ];
  
  const proPlanFeatures = [
    { name: "All Premium features", included: true },
    { name: "Priority vet consultations", included: true },
    { name: "Video training sessions", included: true },
    { name: "Emergency health support", included: true },
    { name: "Multiple pet profiles", included: true },
    { name: "Exclusive product discounts", included: true },
  ];
  
  // Pricing based on billing cycle
  const getPricing = (plan: 'premium' | 'pro') => {
    if (plan === 'premium') {
      return billingCycle === 'monthly' ? 9.99 : 7.99;
    } else {
      return billingCycle === 'monthly' ? 19.99 : 16.99;
    }
  };
  
  // Savings percentage for yearly billing
  const getSavings = (plan: 'premium' | 'pro') => {
    if (plan === 'premium') {
      return Math.round(100 - (7.99 * 12 * 100) / (9.99 * 12));
    } else {
      return Math.round(100 - (16.99 * 12 * 100) / (19.99 * 12));
    }
  };

  return (
    <div className="bg-white dark:bg-gray-900 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold">PRICING PLANS</span>
          <h1 className="text-3xl font-bold mt-2 mb-4 dark:text-white">Choose the Perfect Plan for Your Pet</h1>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Access our AI-powered pet care platform with a plan that fits your needs and budget.
          </p>
          
          <div className="flex justify-center mt-8">
            <div className="inline-flex items-center bg-gray-100 dark:bg-gray-800 rounded-lg p-1">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-4 py-2 rounded-md transition-colors ${
                  billingCycle === 'monthly'
                    ? 'bg-white dark:bg-gray-700 shadow-sm'
                    : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingCycle('yearly')}
                className={`px-4 py-2 rounded-md transition-colors ${
                  billingCycle === 'yearly'
                    ? 'bg-white dark:bg-gray-700 shadow-sm'
                    : 'text-gray-600 dark:text-gray-400'
                }`}
              >
                Yearly <span className="text-green-500 text-xs ml-1">Save 20%</span>
              </button>
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {/* Free Plan */}
          <Card className="bg-neutral-light dark:bg-gray-800 overflow-hidden shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <h3 className="font-bold text-xl mb-2 dark:text-white">Basic</h3>
              <div className="mb-4">
                <span className="text-3xl font-bold dark:text-white">Free</span>
                <span className="text-gray-500 dark:text-gray-400">/month</span>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Essential AI assistance for everyday pet care needs.
              </p>
              <ul className="space-y-3 mb-8">
                {freePlanFeatures.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    {feature.included ? (
                      <CheckIcon className="h-5 w-5 text-secondary mt-0.5 mr-3 flex-shrink-0" />
                    ) : (
                      <XIcon className="h-5 w-5 text-gray-400 mt-0.5 mr-3 flex-shrink-0" />
                    )}
                    <span className={`${feature.included ? 'text-gray-600 dark:text-gray-300' : 'text-gray-400 dark:text-gray-500'}`}>
                      {feature.name}
                    </span>
                  </li>
                ))}
              </ul>
              <Link href="/chat">
                <Button variant="outline" className="w-full">
                  Get Started
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          {/* Premium Plan */}
          <Card className="bg-white dark:bg-gray-900 overflow-hidden shadow-lg border-2 border-primary relative transform scale-105">
            <div className="bg-primary text-white text-center py-1 text-sm font-medium">
              MOST POPULAR
            </div>
            <CardContent className="p-6">
              <h3 className="font-bold text-xl mb-2 dark:text-white">Premium</h3>
              <div className="mb-4 flex items-center">
                <span className="text-3xl font-bold dark:text-white">${getPricing('premium')}</span>
                <span className="text-gray-500 dark:text-gray-400">/{billingCycle === 'monthly' ? 'month' : 'month, billed yearly'}</span>
                
                {billingCycle === 'yearly' && (
                  <span className="ml-2 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 text-xs py-0.5 px-2 rounded-full">
                    Save {getSavings('premium')}%
                  </span>
                )}
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Advanced AI features for comprehensive pet care.
              </p>
              <ul className="space-y-3 mb-8">
                {premiumPlanFeatures.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    {feature.included ? (
                      <CheckIcon className="h-5 w-5 text-secondary mt-0.5 mr-3 flex-shrink-0" />
                    ) : (
                      <XIcon className="h-5 w-5 text-gray-400 mt-0.5 mr-3 flex-shrink-0" />
                    )}
                    <span className={`${feature.included ? 'text-gray-600 dark:text-gray-300' : 'text-gray-400 dark:text-gray-500'}`}>
                      {feature.name}
                    </span>
                  </li>
                ))}
              </ul>
              <Link href="/chat">
                <Button className="w-full bg-primary hover:bg-primary/90">
                  Get Started
                </Button>
              </Link>
            </CardContent>
          </Card>
          
          {/* Pro Plan */}
          <Card className="bg-neutral-light dark:bg-gray-800 overflow-hidden shadow-sm border border-gray-200 dark:border-gray-700 hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <h3 className="font-bold text-xl mb-2 dark:text-white">Pro</h3>
              <div className="mb-4 flex items-center">
                <span className="text-3xl font-bold dark:text-white">${getPricing('pro')}</span>
                <span className="text-gray-500 dark:text-gray-400">/{billingCycle === 'monthly' ? 'month' : 'month, billed yearly'}</span>
                
                {billingCycle === 'yearly' && (
                  <span className="ml-2 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 text-xs py-0.5 px-2 rounded-full">
                    Save {getSavings('pro')}%
                  </span>
                )}
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Premium experience with professional support.
              </p>
              <ul className="space-y-3 mb-8">
                {proPlanFeatures.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    {feature.included ? (
                      <CheckIcon className="h-5 w-5 text-secondary mt-0.5 mr-3 flex-shrink-0" />
                    ) : (
                      <XIcon className="h-5 w-5 text-gray-400 mt-0.5 mr-3 flex-shrink-0" />
                    )}
                    <span className={`${feature.included ? 'text-gray-600 dark:text-gray-300' : 'text-gray-400 dark:text-gray-500'}`}>
                      {feature.name}
                    </span>
                  </li>
                ))}
              </ul>
              <Link href="/chat">
                <Button variant="outline" className="w-full">
                  Get Started
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-12 bg-gray-50 dark:bg-gray-800 rounded-xl p-6 max-w-3xl mx-auto">
          <div className="flex items-center mb-4">
            <i className="fas fa-shield-alt text-primary text-xl mr-3"></i>
            <h3 className="font-semibold text-lg dark:text-white">100% Satisfaction Guarantee</h3>
          </div>
          <p className="text-gray-600 dark:text-gray-300">
            Not satisfied with our service? Get a full refund within 30 days of purchase. No questions asked.
          </p>
        </div>
        
        {/* FAQ Section */}
        <div className="mt-20 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-8 text-center dark:text-white">Frequently Asked Questions</h2>
          
          <div className="space-y-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-lg mb-2 dark:text-white">What's included in the free plan?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                The free plan includes limited AI chat interactions for basic pet health questions, a simple symptom checker, general training tips, and access to our blog articles. It's perfect for pet owners looking to try our service.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-lg mb-2 dark:text-white">Can I upgrade or downgrade my plan later?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Yes, you can upgrade or downgrade your plan at any time. If you upgrade, the new features will be immediately available. If you downgrade, you'll continue to have access to your current plan until the end of your billing cycle.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-lg mb-2 dark:text-white">Is the AI advice a substitute for veterinary care?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                No, our AI assistant provides helpful information and guidance, but it is not a substitute for professional veterinary care. We always recommend consulting with a licensed veterinarian for pet health concerns, especially in emergencies.
              </p>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
              <h3 className="font-semibold text-lg mb-2 dark:text-white">How many pets can I add to my account?</h3>
              <p className="text-gray-600 dark:text-gray-300">
                Free and Premium plans support one pet profile. The Pro plan allows you to add multiple pet profiles, making it ideal for households with several pets.
              </p>
            </div>
          </div>
        </div>
        
        {/* CTA Section */}
        <div className="mt-20 bg-gradient-to-r from-primary to-indigo-800 text-white rounded-xl p-10">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">Ready to Give Your Pet the Best Care?</h2>
            <p className="text-white/80 mb-8">
              Join thousands of pet owners who are using our AI assistant to provide better care, training, and health management for their beloved companions.
            </p>
            <Link href="/chat">
              <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
                Get Started Now <i className="fas fa-arrow-right ml-2"></i>
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;
