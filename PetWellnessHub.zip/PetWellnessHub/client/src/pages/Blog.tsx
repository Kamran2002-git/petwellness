import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

interface Article {
  id: number;
  title: string;
  content: string;
  category: string;
  image: string;
  author: string;
  readTime: number;
  createdAt: string;
}

const Blog = () => {
  // Set page title and meta description
  useEffect(() => {
    document.title = "Pet Care Blog | PetPal AI";
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Discover pet care tips, training guides, and health advice personalized to your pet's needs from our expert-written and AI-recommended articles.");
    }
  }, []);

  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  const { data: articles, isLoading } = useQuery<Article[]>({
    queryKey: ['/api/articles'],
  });
  
  const filteredArticles = selectedCategory
    ? articles?.filter(article => article.category === selectedCategory)
    : articles;
  
  // Unique categories
  const categories = articles 
    ? [...new Set(articles.map(article => article.category))]
    : [];
  
  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'training':
        return 'bg-primary/10 text-primary dark:bg-primary/20';
      case 'health':
        return 'bg-secondary/10 text-secondary dark:bg-secondary/20';
      case 'enrichment':
        return 'bg-accent/10 text-accent dark:bg-accent/20';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200';
    }
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-800 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold">EXPERT CONTENT</span>
          <h1 className="text-3xl font-bold mt-2 mb-4 dark:text-white">AI-Recommended Articles</h1>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Discover pet care tips, training guides, and health advice personalized to your pet's needs.
          </p>
        </div>
        
        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          <Button 
            variant={selectedCategory === null ? "default" : "outline"}
            onClick={() => setSelectedCategory(null)}
            className="rounded-full"
          >
            All
          </Button>
          
          {categories.map(category => (
            <Button 
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              onClick={() => setSelectedCategory(category)}
              className="rounded-full"
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </Button>
          ))}
        </div>
        
        {/* Articles Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map(index => (
              <Card key={index} className="bg-white dark:bg-gray-900 overflow-hidden shadow-sm animate-pulse">
                <div className="h-48 bg-gray-200 dark:bg-gray-700"></div>
                <CardContent className="p-6">
                  <div className="flex items-center mb-3 justify-between">
                    <div className="h-6 w-24 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                    <div className="h-4 w-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  </div>
                  <div className="h-7 w-3/4 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                  <div className="h-4 w-full bg-gray-200 dark:bg-gray-700 rounded mb-1"></div>
                  <div className="h-4 w-2/3 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 mr-2"></div>
                      <div className="h-4 w-24 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    </div>
                    <div className="h-4 w-20 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredArticles && filteredArticles.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredArticles.map(article => (
              <Card key={article.id} className="bg-white dark:bg-gray-900 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                <img 
                  src={article.image} 
                  alt={article.title} 
                  className="w-full h-48 object-cover" 
                />
                <CardContent className="p-6">
                  <div className="flex items-center mb-3 justify-between">
                    <Badge className={getCategoryColor(article.category)}>
                      {article.category.charAt(0).toUpperCase() + article.category.slice(1)}
                    </Badge>
                    <span className="text-gray-500 dark:text-gray-400 text-sm">{article.readTime} min read</span>
                  </div>
                  <h2 className="font-bold text-xl mb-2 dark:text-white">{article.title}</h2>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    {article.content.length > 100 
                      ? `${article.content.substring(0, 100)}...` 
                      : article.content}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 mr-2"></div>
                      <span className="text-sm font-medium dark:text-gray-300">{article.author}</span>
                    </div>
                    <Link href={`/blog/${article.id}`}>
                      <a className="text-primary dark:text-primary font-medium text-sm hover:underline">Read more →</a>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center p-12 bg-white dark:bg-gray-900 rounded-xl shadow-sm">
            <div className="text-5xl mb-4">🐾</div>
            <h3 className="text-xl font-semibold mb-2 dark:text-white">No Articles Found</h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              We couldn't find any articles in this category. Please try another category or check back later.
            </p>
            <Button onClick={() => setSelectedCategory(null)}>View All Articles</Button>
          </div>
        )}
        
        {/* Featured Content */}
        <div className="mt-20">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold dark:text-white">Featured Content</h2>
            <p className="text-gray-600 dark:text-gray-300">Specially curated articles by our pet experts</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white dark:bg-gray-900 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="md:flex">
                <div className="md:w-2/5">
                  <img 
                    src="https://images.unsplash.com/photo-1587300003388-59208cc962cb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400" 
                    alt="Puppy training session" 
                    className="w-full h-48 md:h-full object-cover" 
                  />
                </div>
                <div className="p-6 md:w-3/5">
                  <Badge className="bg-primary/10 text-primary dark:bg-primary/20 mb-3">Training</Badge>
                  <h3 className="font-bold text-xl mb-2 dark:text-white">10 Essential Commands Every Puppy Should Learn</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    Start your puppy's training journey with these fundamental commands that build a strong foundation for good behavior.
                  </p>
                  <Link href="/chat">
                    <Button variant="outline">Get Training Tips</Button>
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-900 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="md:flex">
                <div className="md:w-2/5">
                  <img 
                    src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400" 
                    alt="Cat with healthy eyes" 
                    className="w-full h-48 md:h-full object-cover" 
                  />
                </div>
                <div className="p-6 md:w-3/5">
                  <Badge className="bg-secondary/10 text-secondary dark:bg-secondary/20 mb-3">Health</Badge>
                  <h3 className="font-bold text-xl mb-2 dark:text-white">Understanding Common Cat Eye Problems</h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-4">
                    Learn to recognize signs of eye issues in cats and when to seek veterinary care for optimal feline health.
                  </p>
                  <Link href="/chat">
                    <Button variant="outline">Get Health Advice</Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Newsletter Section */}
        <div className="mt-20 bg-gradient-to-r from-primary/10 to-secondary/10 dark:from-primary/20 dark:to-secondary/20 rounded-xl p-8 md:p-12">
          <div className="md:flex items-center justify-between">
            <div className="md:w-1/2 mb-6 md:mb-0">
              <h2 className="text-2xl font-bold mb-3 dark:text-white">Subscribe to Our Newsletter</h2>
              <p className="text-gray-600 dark:text-gray-300">
                Get the latest pet care tips, training advice, and health updates delivered to your inbox.
              </p>
            </div>
            <div className="md:w-2/5">
              <form className="flex flex-col sm:flex-row gap-3">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="flex-1 px-4 py-2 rounded-md border border-gray-300 dark:border-gray-600 dark:bg-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary" 
                  required
                />
                <Button>Subscribe</Button>
              </form>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                We respect your privacy. Unsubscribe at any time.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;
