import { useEffect } from "react";
import ChatInterface from "@/components/ChatInterface";

const Chat = () => {
  // Set page title and meta description
  useEffect(() => {
    document.title = "Chat with PetPal AI | Virtual Vet & Training Coach";
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Get instant pet health advice and training guidance from our AI assistant. Ask questions about symptoms, behavior issues, and more.");
    }
  }, []);

  return (
    <div className="bg-gray-50 dark:bg-gray-800 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-4 dark:text-white">Chat with PetPal AI</h1>
            <p className="text-gray-600 dark:text-gray-300">
              Get instant answers to your pet health questions, training advice, and product recommendations
            </p>
          </div>
          
          <ChatInterface />
          
          <div className="mt-8 bg-white dark:bg-gray-900 rounded-xl p-6 shadow-sm">
            <h2 className="text-xl font-semibold mb-4 dark:text-white">About PetPal AI</h2>
            <p className="text-gray-600 dark:text-gray-300 mb-4">
              PetPal AI uses advanced artificial intelligence to provide helpful information about pet health, training, and product recommendations. While our AI is trained on veterinary knowledge, it is not a substitute for professional veterinary care.
            </p>
            <div className="p-3 bg-yellow-50 dark:bg-yellow-900/30 border border-yellow-200 dark:border-yellow-800 rounded-lg">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                <i className="fas fa-exclamation-triangle mr-2"></i>
                Always consult with a licensed veterinarian for pet health concerns, especially in emergencies.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;
