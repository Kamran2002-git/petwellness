import Hero from "@/components/Hero";
import Features from "@/components/Features";
import AIInteractionDemo from "@/components/AIInteractionDemo";
import ProductRecommendations from "@/components/ProductRecommendations";
import CTASection from "@/components/CTASection";
import { useEffect } from "react";

const Home = () => {
  // Set page title and meta description
  useEffect(() => {
    document.title = "PetPal AI - Smart Pet Health & Training Assistant";
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Get personalized pet health advice, training plans, and product recommendations for your furry friends from our advanced AI assistant.");
    }
  }, []);

  return (
    <>
      <Hero />
      <Features />
      <AIInteractionDemo />
      <ProductRecommendations />
      <CTASection />
    </>
  );
};

export default Home;
