import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

const PetHealth = () => {
  // Set page title and meta description
  useEffect(() => {
    document.title = "Pet Health Monitoring | PetPal AI";
    
    // Set meta description
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute("content", "Keep track of your pet's health with our AI-powered symptom checker and get personalized advice based on your pet's unique health profile.");
    }
  }, []);

  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const { toast } = useToast();
  
  const commonSymptoms = [
    "Limping", "Fever", "Lethargy", "Vomiting", 
    "Diarrhea", "Coughing", "Sneezing", "Loss of Appetite",
    "Excessive Thirst", "Itching", "Hair Loss", "Bad Breath"
  ];
  
  const handleSymptomToggle = (symptom: string) => {
    if (selectedSymptoms.includes(symptom)) {
      setSelectedSymptoms(selectedSymptoms.filter(s => s !== symptom));
    } else {
      setSelectedSymptoms([...selectedSymptoms, symptom]);
    }
  };
  
  const handleCheckSymptoms = () => {
    if (selectedSymptoms.length === 0) {
      toast({
        title: "No symptoms selected",
        description: "Please select at least one symptom to check",
        variant: "destructive"
      });
      return;
    }
    
    // Redirect to chat with symptoms as initial message
    const symptomsText = selectedSymptoms.join(", ");
    window.location.href = `/chat?message=My pet is showing these symptoms: ${symptomsText}. What could be wrong?&category=health`;
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-800 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-primary font-semibold">PET HEALTH</span>
          <h1 className="text-3xl font-bold mt-2 mb-4 dark:text-white">AI-Enhanced Pet Health Monitoring</h1>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Keep track of your pet's health with our intelligent symptom checker and get personalized advice based on your pet's unique health profile.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-sm mb-6">
              <div className="flex items-center mb-4">
                <div className="bg-primary/10 dark:bg-primary/20 rounded-full p-2 mr-3">
                  <i className="fas fa-heartbeat text-primary"></i>
                </div>
                <h3 className="font-semibold dark:text-white">Symptom Checker</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Our AI analyzes symptoms to help identify potential health issues and recommend appropriate actions.
              </p>
              <div className="flex flex-wrap gap-3 mb-4">
                {commonSymptoms.map((symptom) => (
                  <Badge 
                    key={symptom}
                    variant={selectedSymptoms.includes(symptom) ? "default" : "outline"}
                    className={`cursor-pointer ${selectedSymptoms.includes(symptom) ? "bg-primary" : "hover:bg-primary/10"}`}
                    onClick={() => handleSymptomToggle(symptom)}
                  >
                    {selectedSymptoms.includes(symptom) && (
                      <i className="fas fa-check mr-1 text-xs"></i>
                    )}
                    {symptom}
                  </Badge>
                ))}
              </div>
              <Button 
                className="w-full bg-primary hover:bg-primary/90"
                onClick={handleCheckSymptoms}
                disabled={selectedSymptoms.length === 0}
              >
                Check Symptoms
              </Button>
            </div>
            
            <div className="bg-white dark:bg-gray-900 rounded-xl p-6 shadow-sm">
              <div className="flex items-center mb-4">
                <div className="bg-secondary/10 dark:bg-secondary/20 rounded-full p-2 mr-3">
                  <i className="fas fa-calendar-check text-secondary"></i>
                </div>
                <h3 className="font-semibold dark:text-white">Health Reminders</h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300 mb-4">
                Never miss important vaccinations, medication schedules, or checkups with our AI-powered reminder system.
              </p>
              <div className="space-y-3">
                <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700 flex items-center justify-between">
                  <div className="flex items-center">
                    <i className="fas fa-syringe text-primary mr-3"></i>
                    <div>
                      <p className="text-sm font-medium dark:text-white">Rabies Vaccination</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Due in 2 weeks</p>
                    </div>
                  </div>
                  <Button variant="link" size="sm" className="text-primary">Set Reminder</Button>
                </div>
                <div className="bg-gray-50 dark:bg-gray-800 p-3 rounded-lg border border-gray-200 dark:border-gray-700 flex items-center justify-between">
                  <div className="flex items-center">
                    <i className="fas fa-capsules text-accent mr-3"></i>
                    <div>
                      <p className="text-sm font-medium dark:text-white">Heartworm Medication</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Due in 3 days</p>
                    </div>
                  </div>
                  <Button variant="link" size="sm" className="text-primary">Set Reminder</Button>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {/* A veterinarian examining a golden retriever */}
            <img src="https://images.unsplash.com/photo-1581888227599-779811939961?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=500" alt="Veterinarian examining a dog" className="rounded-xl h-64 object-cover w-full shadow-md" />
            
            {/* A cat being examined by a veterinarian */}
            <img src="https://images.unsplash.com/photo-1560807707-8cc77767d783?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300" alt="Cat being examined by vet" className="rounded-xl h-48 object-cover w-full shadow-md" />
            
            {/* A close-up of a healthy dog's teeth and gums */}
            <img src="https://pixabay.com/get/g1bb608ceb2182af63b66edd349a3426631b97c1f3c53327978a0172b33dad85fdff9617d689ba70e33c8ceb2916bcb526413b88f0dae7d011d36c2f11a588e8e_1280.jpg" alt="Healthy dog teeth and gums" className="rounded-xl h-48 object-cover w-full shadow-md" />
            
            {/* A pet owner using a tablet to track pet health information */}
            <img src="https://images.unsplash.com/photo-1565958011703-44f9829ba187?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=500" alt="Pet owner using tablet for pet health" className="rounded-xl h-64 object-cover w-full shadow-md" />
          </div>
        </div>
        
        <div className="mt-16 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-6 dark:text-white">Common Pet Health Concerns</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white dark:bg-gray-900 p-5 rounded-xl shadow-sm">
              <div className="flex items-center mb-3">
                <div className="bg-red-100 dark:bg-red-900/30 p-2 rounded-full mr-3">
                  <i className="fas fa-exclamation-triangle text-red-500"></i>
                </div>
                <h3 className="font-semibold dark:text-white">Emergency Signs</h3>
              </div>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300 text-sm">
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-red-500"></i>
                  <span>Difficulty breathing</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-red-500"></i>
                  <span>Severe bleeding</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-red-500"></i>
                  <span>Collapse or inability to stand</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-red-500"></i>
                  <span>Seizures</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-red-500"></i>
                  <span>Suspected poisoning</span>
                </li>
              </ul>
              <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                <Link href="/chat">
                  <Button variant="outline" className="w-full text-red-500 border-red-200 dark:border-red-900 hover:bg-red-50 dark:hover:bg-red-900/30">
                    Get Emergency Help
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-900 p-5 rounded-xl shadow-sm">
              <div className="flex items-center mb-3">
                <div className="bg-blue-100 dark:bg-blue-900/30 p-2 rounded-full mr-3">
                  <i className="fas fa-shield-alt text-blue-500"></i>
                </div>
                <h3 className="font-semibold dark:text-white">Preventive Care</h3>
              </div>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300 text-sm">
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-blue-500"></i>
                  <span>Regular vaccinations</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-blue-500"></i>
                  <span>Parasite prevention</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-blue-500"></i>
                  <span>Dental cleanings</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-blue-500"></i>
                  <span>Annual wellness exams</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-blue-500"></i>
                  <span>Weight management</span>
                </li>
              </ul>
              <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                <Link href="/chat">
                  <Button variant="outline" className="w-full text-blue-500 border-blue-200 dark:border-blue-900 hover:bg-blue-50 dark:hover:bg-blue-900/30">
                    Get Preventive Tips
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-900 p-5 rounded-xl shadow-sm">
              <div className="flex items-center mb-3">
                <div className="bg-green-100 dark:bg-green-900/30 p-2 rounded-full mr-3">
                  <i className="fas fa-utensils text-green-500"></i>
                </div>
                <h3 className="font-semibold dark:text-white">Nutrition</h3>
              </div>
              <ul className="space-y-2 text-gray-600 dark:text-gray-300 text-sm">
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-green-500"></i>
                  <span>Age-appropriate diet</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-green-500"></i>
                  <span>Special dietary needs</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-green-500"></i>
                  <span>Proper portion control</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-green-500"></i>
                  <span>Healthy treats</span>
                </li>
                <li className="flex items-start">
                  <i className="fas fa-circle text-xs mt-1 mr-2 text-green-500"></i>
                  <span>Hydration</span>
                </li>
              </ul>
              <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                <Link href="/chat">
                  <Button variant="outline" className="w-full text-green-500 border-green-200 dark:border-green-900 hover:bg-green-50 dark:hover:bg-green-900/30">
                    Get Nutrition Advice
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PetHealth;
