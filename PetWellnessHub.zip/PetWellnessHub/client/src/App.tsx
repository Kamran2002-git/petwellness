import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Cat3dAnimation from "@/components/Cat3dAnimation";
import Home from "@/pages/Home";
import Chat from "@/pages/Chat";
import PetHealth from "@/pages/PetHealth";
import Training from "@/pages/Training";
import Blog from "@/pages/Blog";
import Pricing from "@/pages/Pricing";
import { ThemeProvider } from "@/components/ThemeProvider";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/chat" component={Chat} />
      <Route path="/health" component={PetHealth} />
      <Route path="/training" component={Training} />
      <Route path="/blog" component={Blog} />
      <Route path="/pricing" component={Pricing} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider defaultTheme="light">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Header />
          <main>
            <Router />
          </main>
          <Footer />
          <Cat3dAnimation />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
